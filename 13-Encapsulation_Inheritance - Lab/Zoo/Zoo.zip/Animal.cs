﻿namespace Zoo;

public class Animal
{
    private string _name;

    public Animal (string name)
    {
        this.Name = name;
    }
    public string Name { get; set; }
}
