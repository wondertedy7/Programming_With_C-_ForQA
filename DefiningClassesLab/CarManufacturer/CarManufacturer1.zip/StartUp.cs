﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main()
        {
            Car vw = new Car();

            vw.Make = "VW";
            vw.Model = "MK3";
            vw.Year = 1992;


            Console.WriteLine($"Make: {vw.Make}\nModel: {vw.Model}\nYear: {vw.Year}");
        }
    }
}
