﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarManufacturer
{
    public class Car
    {
        /*string make; // field

        string Make            // property
        {
            get { return make; }  // това е дългият начин на изписване на
            set { make = value; } // пропъртито
        }*/
        // но не е нужно да се пише така, защото C# е достатъчно опростен и можем да напишем само пропъртито по следния начин:
        public string Make { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }

    }
}
