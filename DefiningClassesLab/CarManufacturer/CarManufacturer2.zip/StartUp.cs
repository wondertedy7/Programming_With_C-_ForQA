﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main()
        {
            Car vw = new Car();

            vw.Make = "VW";
            vw.Model = "MK3";
            vw.Year = 1992;
            vw.FuelQuantity = 200;
            vw.FuelConsumption = 200;
            vw.Drive(2000);

            Console.WriteLine(vw.WhoAmI());
        }
    }
}
